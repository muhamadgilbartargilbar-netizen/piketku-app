# PiketKu — Flutter

## Isi
- Login dan daftar akun (SQLite lokal).
- Akun pertama yang didaftarkan otomatis menjadi admin; akun berikutnya menjadi siswa.
- Dashboard jadwal hari ini.
- Jadwal Senin–Sabtu dengan tambah/edit/hapus khusus admin.
- Rekap status piket.
- Pengingat notifikasi harian yang dapat diaktifkan/nonaktifkan.
- Pengaturan dan keluar.

## Cara menjalankan
1. Install Flutter SDK dan Android Studio.
2. Buat project Flutter kosong: `flutter create piketku`
3. Salin `lib/main.dart` dan `pubspec.yaml` dari paket ini ke project.
4. Ganti `android/app/src/main/AndroidManifest.xml` dengan file yang disertakan.
5. Jalankan:
   ```bash
   flutter pub get
   flutter run
   ```
6. Buat APK:
   ```bash
   flutter build apk --release
   ```
   APK ada di `build/app/outputs/flutter-apk/app-release.apk`.

## Catatan penting
- Database disimpan lokal di perangkat (SQLite), belum tersinkron antar-HP.
- Akun pertama otomatis admin. Buat akun pertama sebagai pengelola kelas.
- Status piket dan rekap dihitung dari tanggal aktual. Penandaan status dapat dikembangkan lebih lanjut dengan tombol admin khusus.
- Notifikasi saat ini berupa pengingat harian umum. Penjadwalan jam yang presisi memerlukan konfigurasi Android tambahan dan pengujian pada perangkat.
- Untuk rilis publik, tambahkan validasi admin, pengelolaan akun, backup database, dan kebijakan privasi.
