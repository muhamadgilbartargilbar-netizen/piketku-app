import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:path/path.dart' as p;
import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';

const purple = Color(0xFF7052B5);
const lightPurple = Color(0xFFE9DFFF);
const pale = Color(0xFFF8F4FF);
const ink = Color(0xFF20164A);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('id_ID', null);
  await AppDb.instance.init();
  await ReminderService.instance.init();
  runApp(const PiketKuApp());
}

String hashPassword(String value) => sha256.convert(utf8.encode(value)).toString();

class AppDb {
  AppDb._();
  static final instance = AppDb._();
  late Database db;

  Future<void> init() async {
    final base = await getDatabasesPath();
    db = await openDatabase(p.join(base, 'piketku.db'), version: 1,
      onCreate: (d, version) async {
        await d.execute('''CREATE TABLE users(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
          username TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL)''');
        await d.execute('''CREATE TABLE schedules(
          id INTEGER PRIMARY KEY AUTOINCREMENT, weekday INTEGER NOT NULL,
          day_name TEXT NOT NULL, names TEXT NOT NULL, note TEXT DEFAULT '')''');
        await d.execute('''CREATE TABLE attendance(
          id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT UNIQUE NOT NULL,
          status INTEGER NOT NULL DEFAULT 0, updated_by TEXT DEFAULT '')''');
        await d.execute('''CREATE TABLE settings(
          key TEXT PRIMARY KEY, value TEXT NOT NULL)''');
        final seed = [
          ['Senin','Siti, Rani, Dinda'], ['Selasa','Aulia, Nabila, Fira'],
          ['Rabu','Syifa, Zahra, Putri'], ['Kamis','Dewi, Maya, Intan'],
          ['Jumat','Nayla, Sabrina, Salsabila'], ['Sabtu','Kirani, Haikal, Rafa']
        ];
        for (var i=0;i<seed.length;i++) {
          await d.insert('schedules', {'weekday':i+1,'day_name':seed[i][0],'names':seed[i][1],'note':''});
        }
      });
  }

  Future<Map<String,dynamic>?> login(String username, String password) async {
    final rows = await db.query('users', where:'username=? AND password=?',
      whereArgs:[username.trim(),hashPassword(password)]);
    return rows.isEmpty ? null : rows.first;
  }

  Future<bool> register(String name, String username, String password) async {
    try {
      final count = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM users')) ?? 0;
      await db.insert('users', {'name':name.trim(),'username':username.trim(),
        'password':hashPassword(password),'role':count==0?'admin':'siswa'});
      return true;
    } catch (_) { return false; }
  }

  Future<List<Map<String,dynamic>>> schedules() => db.query('schedules', orderBy:'weekday');
  Future<void> saveSchedule(int? id, int weekday, String day, String names) async {
    final data={'weekday':weekday,'day_name':day,'names':names,'note':''};
    if (id == null) { await db.insert('schedules',data); }
    else { await db.update('schedules',data,where:'id=?',whereArgs:[id]); }
  }
  Future<void> deleteSchedule(int id) => db.delete('schedules',where:'id=?',whereArgs:[id]);
  Future<void> setStatus(DateTime date, bool done, String user) async {
    final key=DateFormat('yyyy-MM-dd').format(date);
    await db.insert('attendance', {'date':key,'status':done?1:0,'updated_by':user},
      conflictAlgorithm:ConflictAlgorithm.replace);
  }
  Future<bool> status(DateTime date) async {
    final key=DateFormat('yyyy-MM-dd').format(date);
    final rows=await db.query('attendance',where:'date=?',whereArgs:[key]);
    return rows.isNotEmpty && rows.first['status']==1;
  }
  Future<List<Map<String,dynamic>>> attendanceBetween(DateTime start, DateTime end) =>
    db.query('attendance',where:'date>=? AND date<=?',
      whereArgs:[DateFormat('yyyy-MM-dd').format(start),DateFormat('yyyy-MM-dd').format(end)]);
}

class ReminderService {
  ReminderService._();
  static final instance=ReminderService._();
  final plugin=FlutterLocalNotificationsPlugin();
  Future<void> init() async {
    const android=AndroidInitializationSettings('@mipmap/ic_launcher');
    await plugin.initialize(const InitializationSettings(android:android));
    await plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
      ?.requestNotificationsPermission();
  }
  Future<void> scheduleDaily() async {
    // Pengingat harian pukul 07.00. Android meminta izin notifikasi saat pertama kali.
    await plugin.periodicallyShow(100, 'Pengingat Piket',
      'Cek jadwal piket kelasmu hari ini di PiketKu.',
      RepeatInterval.daily,
      const NotificationDetails(android:AndroidNotificationDetails(
        'piketku_daily','Pengingat Piket',
        channelDescription:'Pengingat jadwal piket harian',
        importance:Importance.high, priority:Priority.high)),
      androidScheduleMode:AndroidScheduleMode.inexactAllowWhileIdle);
  }
  Future<void> cancel() => plugin.cancel(100);
}

class PiketKuApp extends StatelessWidget {
  const PiketKuApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    title:'PiketKu', debugShowCheckedModeBanner:false,
    theme:ThemeData(useMaterial3:true, scaffoldBackgroundColor:pale,
      colorScheme:ColorScheme.fromSeed(seedColor:purple),
      fontFamily:'Roboto', appBarTheme:const AppBarTheme(
        backgroundColor:pale, foregroundColor:ink, elevation:0)),
    home:const AuthPage());
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override State<AuthPage> createState()=>_AuthPageState();
}
class _AuthPageState extends State<AuthPage> {
  final user=TextEditingController(), pass=TextEditingController();
  bool register=false, busy=false, obscure=true;
  final name=TextEditingController();
  String? error;
  Future<void> submit() async {
    setState(()=>busy=true); error=null;
    if(register) {
      if(name.text.trim().isEmpty || user.text.trim().isEmpty || pass.text.length<6) {
        error='Isi semua data. Password minimal 6 karakter.';
      } else {
        final ok=await AppDb.instance.register(name.text,user.text,pass.text);
        if(ok) { error='Akun berhasil dibuat. Silakan masuk.'; register=false; }
        else { error='Username sudah digunakan.'; }
      }
    } else {
      final result=await AppDb.instance.login(user.text,pass.text);
      if(result!=null && mounted) {
        final prefs=await SharedPreferences.getInstance();
        await prefs.setInt('userId',result['id'] as int);
        await prefs.setString('userName',result['name'] as String);
        await prefs.setString('role',result['role'] as String);
        Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>HomeShell(
          userName:result['name'] as String, role:result['role'] as String)));
      } else { error='Username atau password salah!'; }
    }
    if(mounted) setState(()=>busy=false);
  }
  @override Widget build(BuildContext context)=>Scaffold(
    body:Container(decoration:const BoxDecoration(gradient:LinearGradient(
      colors:[Color(0xFFE6D9FF),Color(0xFFFFFBFF)],begin:Alignment.topCenter,end:Alignment.bottomCenter)),
      child:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(26),
        child:Container(padding:const EdgeInsets.all(24),decoration:BoxDecoration(
          color:Colors.white.withOpacity(.88),borderRadius:BorderRadius.circular(32),
          border:Border.all(color:lightPurple,width:2)),
          child:Column(children:[
            const Icon(Icons.cleaning_services_rounded,size:72,color:purple),
            const SizedBox(height:8),
            const Text('PiketKu',style:TextStyle(fontSize:38,fontWeight:FontWeight.w900,color:purple)),
            const Text('Ingat Jadwal Piket,\\nJaga Kelas Tetap Bersih!',
              textAlign:TextAlign.center,style:TextStyle(fontSize:16,fontWeight:FontWeight.w700,color:ink)),
            const SizedBox(height:28),
            if(register) _field(name,'Nama lengkap',Icons.badge_outlined),
            _field(user,'Username',Icons.person),
            _field(pass,'Password',Icons.lock,secret:true),
            if(error!=null) Padding(padding:const EdgeInsets.only(top:10),
              child:Text(error!,style:TextStyle(color:error!.contains('berhasil')?Colors.green:Colors.red))),
            const SizedBox(height:18),
            SizedBox(width:double.infinity,height:50,child:FilledButton(
              style:FilledButton.styleFrom(backgroundColor:purple),
              onPressed:busy?null:submit,child:Text(busy?'Memproses...':register?'Daftar':'Masuk',
                style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)))),
            TextButton(onPressed:()=>setState(()=>{register=!register,error=null}),
              child:Text(register?'Sudah punya akun? Masuk':'Belum punya akun? Daftar',
                style:const TextStyle(color:ink,fontWeight:FontWeight.bold)))
          ])))))));
  Widget _field(TextEditingController c,String hint,IconData icon,{bool secret=false})=>
    Padding(padding:const EdgeInsets.only(bottom:10),child:TextField(controller:c,
      obscureText:secret && obscure, decoration:InputDecoration(
        prefixIcon:Icon(icon,color:purple),hintText:hint,filled:true,fillColor:pale,
        border:OutlineInputBorder(borderRadius:BorderRadius.circular(24),
          borderSide:const BorderSide(color:lightPurple)),
        enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(24),
          borderSide:const BorderSide(color:lightPurple)),
        suffixIcon:secret?IconButton(icon:Icon(obscure?Icons.visibility:Icons.visibility_off),
          onPressed:()=>setState(()=>obscure=!obscure)):null)));
}

class HomeShell extends StatefulWidget {
  final String userName,role;
  const HomeShell({super.key,required this.userName,required this.role});
  @override State<HomeShell> createState()=>_HomeShellState();
}
class _HomeShellState extends State<HomeShell> {
  int index=0;
  final titles=['Beranda','Jadwal Piket','Rekap Piket','Pengingat Piket','Pengaturan'];
  @override Widget build(BuildContext context) {
    final pages=[
      DashboardPage(userName:widget.userName),
      SchedulePage(isAdmin:widget.role=='admin'),
      const RecapPage(),
      ReminderPage(userName:widget.userName),
      SettingsPage(userName:widget.userName)
    ];
    return Scaffold(
      appBar:AppBar(title:Text(titles[index],style:const TextStyle(fontWeight:FontWeight.w800))),
      drawer:Drawer(backgroundColor:purple,child:SafeArea(child:Column(children:[
        const SizedBox(height:18),const Icon(Icons.cleaning_services,size:58,color:Colors.white),
        const Text('PiketKu',style:TextStyle(fontSize:28,color:Colors.white,fontWeight:FontWeight.bold)),
        Padding(padding:const EdgeInsets.all(12),child:Text('Halo, ${widget.userName}',
          style:const TextStyle(color:Colors.white70))),
        const Divider(color:Colors.white30),
        ...List.generate(titles.length,(i)=>ListTile(
          selected:index==i,selectedTileColor:const Color(0xFF9A7AE0),
          leading:Icon([Icons.home,Icons.calendar_month,Icons.check_box,Icons.notifications,Icons.settings][i],color:Colors.white),
          title:Text(titles[i],style:const TextStyle(color:Colors.white)),
          onTap:(){setState(()=>index=i);Navigator.pop(context);})),
        const Spacer(),
        ListTile(leading:const Icon(Icons.logout,color:Colors.white),
          title:const Text('Keluar',style:TextStyle(color:Colors.white)),
          onTap:() async {final p=await SharedPreferences.getInstance();await p.clear();
            if(context.mounted) Navigator.pushAndRemoveUntil(context,
              MaterialPageRoute(builder:(_)=>const AuthPage()),(_)=>false);})
      ]))),
      body:pages[index]);
  }
}

Widget pagePadding(Widget child)=>SingleChildScrollView(padding:const EdgeInsets.all(16),child:child);
Widget panel(Widget child)=>Container(width:double.infinity,padding:const EdgeInsets.all(18),
  decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(24),
    border:Border.all(color:lightPurple),boxShadow:[BoxShadow(
      color:purple.withOpacity(.06),blurRadius:12,offset:const Offset(0,4))]),child:child);
Widget heading(String text)=>Text(text,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900,color:ink));

class DashboardPage extends StatefulWidget {
  final String userName;
  const DashboardPage({super.key,required this.userName});
  @override State<DashboardPage> createState()=>_DashboardPageState();
}
class _DashboardPageState extends State<DashboardPage> {
  List<Map<String,dynamic>> rows=[];
  bool done=false;
  @override void initState(){super.initState();load();}
  Future<void> load() async {
    rows=await AppDb.instance.schedules();done=await AppDb.instance.status(DateTime.now());
    if(mounted)setState((){});
  }
  @override Widget build(BuildContext context) {
    final now=DateTime.now(); final today=now.weekday;
    final item=rows.where((e)=>e['weekday']==today).toList();
    final names=item.isEmpty?'Tidak ada jadwal piket':item.first['names'] as String;
    return pagePadding(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('Halo, ${widget.userName}! 👋',style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900,color:ink)),
      const Text('Yuk cek jadwal piket hari ini!',style:TextStyle(color:ink)),
      const SizedBox(height:16),
      panel(Column(children:[
        const Icon(Icons.calendar_month,size:38,color:purple),
        heading('Piket Hari Ini!'),
        Text(DateFormat('EEEE', 'id_ID').format(now),style:const TextStyle(fontSize:34,fontWeight:FontWeight.w900,color:ink)),
        const SizedBox(height:16),
        _info(Icons.groups,'Nama Piket',names),
        const SizedBox(height:10),
        _info(Icons.check_circle,'Status',done?'Selesai':'Belum Piket'),
        const SizedBox(height:12),
        SizedBox(width:double.infinity,child:FilledButton.icon(
          style:FilledButton.styleFrom(backgroundColor:done?Colors.green:purple),
          onPressed:() async {
            final prefs=await SharedPreferences.getInstance();
            final who=prefs.getString('userName')??widget.userName;
            await AppDb.instance.setStatus(now,!done,who);
            await load();
          },
          icon:Icon(done?Icons.undo:Icons.check),
          label:Text(done?'Batalkan status selesai':'Tandai Piket Selesai'))),
        const SizedBox(height:12),
        Text('Kelas bersih, belajar pun lebih nyaman! 😊',
          style:TextStyle(color:purple,fontWeight:FontWeight.w700))
      ])),
      const SizedBox(height:16),
      panel(Row(children:[const Icon(Icons.today,color:purple),const SizedBox(width:10),
        Expanded(child:Text(DateFormat('EEEE, d MMMM yyyy','id_ID').format(now),
          style:const TextStyle(fontWeight:FontWeight.bold,color:ink)))]))
    ]));
  }
  Widget _info(IconData icon,String title,String value)=>Container(
    padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:lightPurple,borderRadius:BorderRadius.circular(18)),
    child:Row(children:[Icon(icon,color:purple,size:30),const SizedBox(width:12),
      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(title,style:const TextStyle(color:ink)),Text(value,
          style:const TextStyle(fontSize:17,fontWeight:FontWeight.w800,color:ink))]))]));
}

class SchedulePage extends StatefulWidget {
  final bool isAdmin;
  const SchedulePage({super.key,required this.isAdmin});
  @override State<SchedulePage> createState()=>_SchedulePageState();
}
class _SchedulePageState extends State<SchedulePage> {
  List<Map<String,dynamic>> rows=[];
  @override void initState(){super.initState();load();}
  Future<void> load() async {rows=await AppDb.instance.schedules();if(mounted)setState((){});}
  Future<void> edit([Map<String,dynamic>? row]) async {
    final names=TextEditingController(text:row?['names']??'');
    int day=row?['weekday']??1;
    final dayNames=['','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu'];
    await showDialog(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,ss)=>AlertDialog(
      title:Text(row==null?'Tambah Jadwal':'Edit Jadwal'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        DropdownButtonFormField<int>(value:day,decoration:const InputDecoration(labelText:'Hari'),
          items:List.generate(6,(i)=>DropdownMenuItem(value:i+1,child:Text(dayNames[i+1]))),
          onChanged:(v)=>ss(()=>day=v??1)),
        TextField(controller:names,decoration:const InputDecoration(labelText:'Nama siswa (pisahkan koma)'))
      ]),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Batal')),
        FilledButton(onPressed:() async {if(names.text.trim().isNotEmpty){
          await AppDb.instance.saveSchedule(row?['id'],day,dayNames[day],names.text);
          if(ctx.mounted)Navigator.pop(ctx);await load();}},child:const Text('Simpan'))])));
  }
  @override Widget build(BuildContext context)=>pagePadding(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Row(children:[Expanded(child:heading('Jadwal Piket')),if(widget.isAdmin)
      IconButton(onPressed:()=>edit(),icon:const Icon(Icons.add_circle,color:purple,size:32))]),
    const SizedBox(height:12),
    panel(Column(children:[
      Row(children:[_cell('Hari',true),_cell('Nama Piket',true),_cell('Aksi',true)]),
      const Divider(),
      ...rows.map((r)=>Column(children:[
        Row(children:[_cell(r['day_name'],false),_cell(r['names'],false),
          if(widget.isAdmin)Row(children:[
            IconButton(onPressed:()=>edit(r),icon:const Icon(Icons.edit,color:purple)),
            IconButton(onPressed:()async{await AppDb.instance.deleteSchedule(r['id']);await load();},
              icon:const Icon(Icons.delete_outline,color:Colors.red))
          ]) else const SizedBox(width:8)]),
        const Divider(height:8)
      ]))
    ]))
  ]));
  Widget _cell(String text,bool bold)=>Expanded(flex: bold?2:3,child:Padding(
    padding:const EdgeInsets.symmetric(vertical:8,horizontal:4),
    child:Text(text,style:TextStyle(fontWeight:bold?FontWeight.w900:FontWeight.w600,color:ink))));
}

class RecapPage extends StatefulWidget {
  const RecapPage({super.key});
  @override State<RecapPage> createState()=>_RecapPageState();
}
class _RecapPageState extends State<RecapPage> {
  List<Map<String,dynamic>> rows=[];
  List<Map<String,dynamic>> records=[];
  String period='Minggu Ini';
  @override void initState(){super.initState();load();}
  Future<void> load() async {
    rows=await AppDb.instance.schedules();
    final now=DateTime.now(); final start=period=='Hari Ini'?DateTime(now.year,now.month,now.day):
      period=='Bulan Ini'?DateTime(now.year,now.month,1):now.subtract(Duration(days:now.weekday-1));
    final end=period=='Hari Ini'?start:period=='Bulan Ini'?DateTime(now.year,now.month+1,0):start.add(const Duration(days:6));
    records=await AppDb.instance.attendanceBetween(start,end);
    if(mounted)setState((){});
  }
  @override Widget build(BuildContext context) {
    final done=records.where((e)=>e['status']==1).length;
    final total=period=='Hari Ini'?1:period=='Bulan Ini'?DateTime.now().day:6;
    return pagePadding(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[Expanded(child:heading('Rekap Piket')),
        DropdownButton<String>(value:period,items:['Hari Ini','Minggu Ini','Bulan Ini']
          .map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),
          onChanged:(v){period=v??'Minggu Ini';load();})]),
      const SizedBox(height:12),
      Row(children:[
        _stat('Piket Selesai','$done Hari',Colors.green.shade100,Icons.check_circle),
        const SizedBox(width:8),
        _stat('Belum Piket','${(total-done).clamp(0,total)} Hari',lightPurple,Icons.access_time),
        const SizedBox(width:8),
        _stat('Total Piket','$total Hari',const Color(0xFFFFE9B8),Icons.star)
      ]),
      const SizedBox(height:16),
      panel(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        heading('Detail Rekap'),const SizedBox(height:8),
        ...rows.map((r){
          final today=DateTime.now();
          final date=DateTime(today.year,today.month,today.day)
            .subtract(Duration(days:today.weekday-(r['weekday'] as int)));
          final found=records.where((e)=>e['date']==DateFormat('yyyy-MM-dd').format(date)).toList();
          final isDone=found.isNotEmpty && found.first['status']==1;
          return ListTile(contentPadding:EdgeInsets.zero,
            title:Text(r['day_name'],style:const TextStyle(fontWeight:FontWeight.bold)),
            trailing:Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:6),
              decoration:BoxDecoration(color:isDone?Colors.green.shade100:const Color(0xFFFFE4B5),
                borderRadius:BorderRadius.circular(18)),
              child:Text(isDone?'Selesai ✓':'Belum ⚠',style:const TextStyle(fontWeight:FontWeight.bold))));
        })
      ]))
    ]));
  }
  Widget _stat(String title,String value,Color color,IconData icon)=>Expanded(child:Container(
    padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:color,borderRadius:BorderRadius.circular(18)),
    child:Column(children:[Icon(icon,color:purple),Text(title,textAlign:TextAlign.center,
      style:const TextStyle(fontSize:11,fontWeight:FontWeight.bold,color:ink)),
      Text(value,style:const TextStyle(fontWeight:FontWeight.w900,color:ink))])));
}

class ReminderPage extends StatefulWidget {
  final String userName;
  const ReminderPage({super.key,required this.userName});
  @override State<ReminderPage> createState()=>_ReminderPageState();
}
class _ReminderPageState extends State<ReminderPage> {
  List<Map<String,dynamic>> rows=[];
  bool enabled=true;
  @override void initState(){super.initState();load();}
  Future<void> load() async {rows=await AppDb.instance.schedules();if(mounted)setState((){});}
  @override Widget build(BuildContext context) {
    final item=rows.where((e)=>e['weekday']==DateTime.now().weekday).toList();
    final names=item.isEmpty?'Tidak ada jadwal':item.first['names'];
    return pagePadding(panel(Column(children:[
      const SizedBox(height:12),const Icon(Icons.notifications_active,size:76,color:purple),
      heading('Pengingat Piket'),const SizedBox(height:18),
      const Text('Hari ini adalah jadwal piket untuk kelompok:',
        textAlign:TextAlign.center,style:TextStyle(fontSize:16,fontWeight:FontWeight.bold,color:ink)),
      const SizedBox(height:16),
      Container(width:double.infinity,padding:const EdgeInsets.all(16),
        decoration:BoxDecoration(color:lightPurple,borderRadius:BorderRadius.circular(30)),
        child:Text(names,textAlign:TextAlign.center,style:const TextStyle(fontSize:19,fontWeight:FontWeight.w900,color:ink))),
      const SizedBox(height:16),
      const Text('Jangan lupa membersihkan kelas setelah jam pelajaran selesai, ya!',
        textAlign:TextAlign.center,style:TextStyle(color:ink)),
      const SizedBox(height:18),
      SwitchListTile(title:const Text('Aktifkan notifikasi'),value:enabled,
        onChanged:(v)async{setState(()=>enabled=v);if(v){await ReminderService.instance.scheduleDaily();}
          else{await ReminderService.instance.cancel();}}),
      FilledButton(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content:Text('Semangat menjaga kelas tetap bersih!'))),
        style:FilledButton.styleFrom(backgroundColor:purple),child:const Text('Oke!'))
    ])));
  }
}

class SettingsPage extends StatelessWidget {
  final String userName;
  const SettingsPage({super.key,required this.userName});
  @override Widget build(BuildContext context)=>pagePadding(Column(children:[
    panel(Column(children:[
      const CircleAvatar(radius:38,backgroundColor:lightPurple,child:Icon(Icons.person,size:44,color:purple)),
      const SizedBox(height:10),heading(userName),
      const Text('Pengguna PiketKu',style:TextStyle(color:ink))
    ])),
    const SizedBox(height:12),
    panel(Column(children:[
      const ListTile(leading:Icon(Icons.info_outline,color:purple),title:Text('Tentang PiketKu'),
        subtitle:Text('Aplikasi pengingat dan pengelola jadwal piket kelas.')),
      const Divider(),
      ListTile(leading:const Icon(Icons.notifications_active,color:purple),
        title:const Text('Uji notifikasi'),onTap:()async{
          await ReminderService.instance.scheduleDaily();
          if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content:Text('Pengingat harian diaktifkan.')));
        }),
      const ListTile(leading:Icon(Icons.verified,color:purple),title:Text('Versi aplikasi'),trailing:Text('1.0.0'))
    ]))
  ]));
}
